from __future__ import annotations

import torch
from dataclasses import MISSING
from typing import TYPE_CHECKING, Sequence

from isaaclab.managers import CommandTerm, CommandTermCfg
from isaaclab.utils import configclass
from isaaclab.utils.math import sample_uniform, quat_rotate_inverse

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv

class MotionCommand(CommandTerm):
    """
    [T1 Gym Logic 구현]
    목표 속도(Velocity)와 보행 박자(Gait Clock)를 동시에 생성하는 Command Manager.
    T1의 _resample_commands 와 step 로직을 통합했습니다.
    """
    cfg: MotionCommandCfg

    def __init__(self, cfg: MotionCommandCfg, env: ManagerBasedRLEnv):
        super().__init__(cfg, env)
        
        # 로봇 객체 (Metric 계산용)
        self.robot = env.scene[cfg.asset_name]
        
        # 1. 속도 명령 (vx, vy, wz)
        self.command_actions = torch.zeros(self.num_envs, 3, device=self.device)
        
        # 2. 보행 박자 (Gait Clock)
        # gait_phase: 0.0 ~ 1.0 사이를 반복 (0.0: 왼발 swing 시작, 0.5: 오른발 swing 시작 등)
        self.gait_phase = torch.zeros(self.num_envs, device=self.device)
        self.gait_freq = torch.zeros(self.num_envs, device=self.device)
        
        # 리샘플링 타이머
        self.time_left = torch.zeros(self.num_envs, device=self.device)
        
        # 메트릭 초기화
        self.metrics["error_lin_vel_xy"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_ang_vel_z"] = torch.zeros(self.num_envs, device=self.device)

    @property
    def command(self) -> torch.Tensor:
        """
        Observation에 들어갈 데이터입니다.
        T1 Gym은 [vx, vy, wz, sin(phase), cos(phase)] 형태로 관측값을 구성합니다.
        여기서는 속도 3개만 리턴하고, sin/cos는 Observation 설정에서 처리하거나,
        여기서 5개를 합쳐서 리턴할 수도 있습니다.
        
        일단은 표준적인 속도(3개)만 리턴합니다.
        (Gait Sin/Cos는 별도의 ObservationTerm으로 gait_phase를 참조하여 만듭니다)
        """
        return self.command_actions

    def _resample_command(self, env_ids: Sequence[int]):
        """
        명령 및 보행 주파수 재설정 (T1 Gym: _resample_commands)
        """
        if len(env_ids) == 0:
            return

        # 1. 속도 랜덤 샘플링
        self.command_actions[env_ids, 0] = sample_uniform(
            self.cfg.ranges.lin_vel_x[0], self.cfg.ranges.lin_vel_x[1], 
            (len(env_ids),), device=self.device
        )
        self.command_actions[env_ids, 1] = sample_uniform(
            self.cfg.ranges.lin_vel_y[0], self.cfg.ranges.lin_vel_y[1], 
            (len(env_ids),), device=self.device
        )
        self.command_actions[env_ids, 2] = sample_uniform(
            self.cfg.ranges.ang_vel_z[0], self.cfg.ranges.ang_vel_z[1], 
            (len(env_ids),), device=self.device
        )
        
        # 2. 보행 주파수 랜덤 샘플링 (예: 1.5Hz ~ 3.0Hz)
        self.gait_freq[env_ids] = sample_uniform(
            self.cfg.ranges.gait_freq[0], self.cfg.ranges.gait_freq[1],
            (len(env_ids),), device=self.device
        )
        
        # 3. 정지 상태(Standing) 확률 적용 (옵션)
        # 10% 확률로 속도와 주파수를 0으로 만들어 제자리 서기 훈련
        if self.cfg.still_proportion > 0:
            # env_ids 중에서 일부를 선택
            num_still = int(len(env_ids) * self.cfg.still_proportion)
            if num_still > 0:
                subset_indices = torch.randperm(len(env_ids))[:num_still]
                still_ids = torch.tensor(env_ids, device=self.device)[subset_indices]
                
                self.command_actions[still_ids] = 0.0
                self.gait_freq[still_ids] = 0.0

        # 타이머 리셋
        self.time_left[env_ids] = sample_uniform(
                self.cfg.resampling_time_range[0],
                self.cfg.resampling_time_range[1],
                (len(env_ids),),
                device=self.device,
            )

    def _update_command(self):
        """
        매 스텝 호출: Gait Phase 업데이트 및 리샘플링 체크
        """
        dt = self._env.step_dt
        
        # 1. Gait Phase 업데이트 (이게 있어야 Reward에서 발 스윙 타이밍을 알 수 있음)
        # phase = (phase + dt * freq) % 1.0
        self.gait_phase = (self.gait_phase + dt * self.gait_freq) % 1.0
        
        # 2. 리샘플링 체크
        self.time_left -= dt
        env_ids = (self.time_left <= 0).nonzero(as_tuple=False).flatten()
        if len(env_ids) > 0:
            self._resample_command(env_ids)
            
        # 3. 메트릭 업데이트
        self._update_metrics()

    def _update_metrics(self):
        """
        Metric 업데이트 (Base Frame 기준 속도 오차)
        """
        # Isaac Lab은 root_lin_vel_b (Base Frame 선속도)를 제공합니다.
        # T1 Gym은 World 속도를 Base Quaternion으로 회전시켜 계산했습니다.
        # 여기서는 Isaac Lab의 기능을 활용해 Base Frame 속도를 바로 씁니다.
        
        lin_vel_b = self.robot.data.root_lin_vel_b[:, :2]  # XY
        ang_vel_b = self.robot.data.root_ang_vel_b[:, 2]   # Z (Yaw)
        
        target_lin_vel = self.command_actions[:, :2]
        target_ang_vel = self.command_actions[:, 2]
        
        # 에러 계산
        self.metrics["error_lin_vel_xy"] = torch.norm(target_lin_vel - lin_vel_b, dim=-1)
        self.metrics["error_ang_vel_z"] = torch.abs(target_ang_vel - ang_vel_b)

    def _set_debug_vis_impl(self, debug_vis: bool):
        pass

    def _debug_vis_callback(self, event):
        pass


@configclass
class MotionCommandCfg(CommandTermCfg):
    """
    T1 학습용 Command 설정
    """
    class_type: type = MotionCommand

    asset_name: str = MISSING
    
    # 속도 및 주파수 범위
    @configclass 
    class Ranges:
        lin_vel_x: tuple[float, float] = (-1.0, 2.0)  # m/s
        lin_vel_y: tuple[float, float] = (-0.5, 0.5)  # m/s
        ang_vel_z: tuple[float, float] = (-1.0, 1.0)  # rad/s
        gait_freq: tuple[float, float] = (1.5, 2.5)   # Hz (걸음 빠르기)
        
    ranges: Ranges = Ranges()
    
    resampling_time_range: tuple[float, float] = (3.0,5.0)
    
    # 정지 상태 비율 (0.0 ~ 1.0)
    still_proportion: float = 0.15 # T1.yaml의 still_proportion 참고