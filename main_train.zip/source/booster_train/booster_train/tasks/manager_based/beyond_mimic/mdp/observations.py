from __future__ import annotations

import torch
from dataclasses import MISSING

from isaaclab.utils import configclass
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
import isaaclab.envs.mdp as mdp

# [수정] 노이즈 설정을 위해 AdditiveGaussianNoiseCfg를 임포트합니다.
from isaaclab.utils.noise import AdditiveGaussianNoiseCfg

# 커스텀 함수(Gait Clock) 정의
def gait_clock_sin(env):
    """Gait Phase의 Sine 값 계산"""
    cmd = env.command_manager.get_term("base_velocity")
    return torch.sin(2 * torch.pi * cmd.gait_phase).unsqueeze(1)

def gait_clock_cos(env):
    """Gait Phase의 Cosine 값 계산"""
    cmd = env.command_manager.get_term("base_velocity")
    return torch.cos(2 * torch.pi * cmd.gait_phase).unsqueeze(1)

def feet_contact_state(env):
    """발이 땅에 닿아있는지 여부를 Boolean/Float 형태로 반환"""
    contact_sensor = env.scene.sensors["contact_forces"]
    
    # 1. 센서가 추적 중인 전체 바디 중에서 발바닥 링크의 정확한 ID(인덱스)를 자동으로 찾습니다.
    # (반환값 중 첫 번째 요소가 인덱스 리스트입니다)
    feet_indices, _ = contact_sensor.find_bodies(["left_foot_link", "right_foot_link"])
    
    # 2. 찾아낸 발바닥 인덱스의 힘(Force) 데이터만 추출합니다.
    forces = contact_sensor.data.net_forces_w[:, feet_indices, :]
    
    # 3. 가해진 힘의 크기(Norm)가 1.0 뉴턴(N) 이상이면 땅에 닿은 것(1.0), 아니면 공중(0.0)으로 처리
    return (torch.norm(forces, dim=-1) > 1.0).float()

@configclass
class ObservationsCfg:
    """Observation specifications for the T1 Locomotion MDP."""

    @configclass
    class PolicyCfg(ObsGroup):
        """Observations for policy group."""
        
        # 1. Base Velocity
        base_lin_vel = ObsTerm(
            func=mdp.base_lin_vel, 
            noise=AdditiveGaussianNoiseCfg(std=0.1), 
            scale=2.0
        )
        base_ang_vel = ObsTerm(
            func=mdp.base_ang_vel, 

            noise=AdditiveGaussianNoiseCfg(std=0.2), 
            scale=0.25
        )
        
        # 2. Projected Gravity
        projected_gravity = ObsTerm(
            func=mdp.projected_gravity,

            noise=AdditiveGaussianNoiseCfg(std=0.05),
        )
        
        # 3. Commands (Velocity)
        velocity_commands = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "base_velocity"},
            scale={"lin_vel_x": 2.0, "lin_vel_y": 2.0, "ang_vel_z": 0.25}
        )
        
        # 4. Gait Clock (Sin/Cos)
        gait_clock_sin = ObsTerm(func=gait_clock_sin)
        gait_clock_cos = ObsTerm(func=gait_clock_cos)
        
        # 5. Joint States
        joint_pos = ObsTerm(
            func=mdp.joint_pos_rel, 

            noise=AdditiveGaussianNoiseCfg(std=0.01), 
            scale=1.0
        )
        joint_vel = ObsTerm(
            func=mdp.joint_vel, 
            noise=AdditiveGaussianNoiseCfg(std=1.5), 
            scale=0.05
        )

        feet_contact = ObsTerm(func=feet_contact_state)

        # 6. Last Actions
        actions = ObsTerm(func=mdp.last_action)
        
        def __post_init__(self):
            self.enable_corruption = True
            self.concatenate_terms = True

    # Critic Observation
    critic: PolicyCfg = PolicyCfg()