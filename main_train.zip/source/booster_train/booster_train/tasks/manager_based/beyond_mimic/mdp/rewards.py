from __future__ import annotations

import torch
from typing import TYPE_CHECKING

from isaaclab.managers import SceneEntityCfg, RewardTermCfg
from isaaclab.sensors import ContactSensor
from isaaclab.utils import configclass
from isaaclab.envs import ManagerBasedRLEnv
import isaaclab.envs.mdp as mdp

# T1 Logic에 필요한 커스텀 Command 클래스 임포트
# (경로는 프로젝트 구조에 맞춰 조정 필요, 현재 구조 기준)
from . import commands as custom_commands

if TYPE_CHECKING:
    from .commands import MotionCommand


# --- 유틸리티 및 보상 계산 함수 구현 ---

def track_lin_vel_x_exp(
    env: ManagerBasedRLEnv, command_name: str, std: float
) -> torch.Tensor:
    """[T1 Logic] X축 선속도 추적 (Exponential Kernel)"""
    # 명령 가져오기
    command: MotionCommand = env.command_manager.get_term(command_name)
    
    # 로봇의 Base Frame 속도 (Isaac Lab 표준: root_lin_vel_b)
    robot = env.scene[command.cfg.asset_name]
    lin_vel_b = robot.data.root_lin_vel_b
    
    # 명령: command_actions[:, 0] (X속도)
    target_vel_x = command.command_actions[:, 0]
    
    error = torch.square(target_vel_x - lin_vel_b[:, 0])
    return torch.exp(-error / std)


def track_lin_vel_y_exp(
    env: ManagerBasedRLEnv, command_name: str, std: float
) -> torch.Tensor:
    """[T1 Logic] Y축 선속도 추적 (Exponential Kernel)"""
    command: MotionCommand = env.command_manager.get_term(command_name)
    robot = env.scene[command.cfg.asset_name]
    lin_vel_b = robot.data.root_lin_vel_b
    
    target_vel_y = command.command_actions[:, 1]
    
    error = torch.square(target_vel_y - lin_vel_b[:, 1])
    return torch.exp(-error / std)


def track_ang_vel_z_exp(
    env: ManagerBasedRLEnv, command_name: str, std: float
) -> torch.Tensor:
    """[T1 Logic] Z축 회전속도(Yaw) 추적 (Exponential Kernel)"""
    command: MotionCommand = env.command_manager.get_term(command_name)
    robot = env.scene[command.cfg.asset_name]
    ang_vel_b = robot.data.root_ang_vel_b
    
    target_ang_vel = command.command_actions[:, 2]
    
    error = torch.square(target_ang_vel - ang_vel_b[:, 2])
    return torch.exp(-error / std)


def feet_swing_reward(
    env: ManagerBasedRLEnv, 
    command_name: str, 
    sensor_cfg: SceneEntityCfg, 
    swing_period: float = 0.5
) -> torch.Tensor:
    """
    [T1 Logic] Gait Phase에 따른 발 스윙 보상
    """
    # 1. Gait Phase 가져오기
    command: MotionCommand = env.command_manager.get_term(command_name)
    if not hasattr(command, "gait_phase"):
        return torch.zeros(env.num_envs, device=env.device)
        
    gait_phase = command.gait_phase  # 0.0 ~ 1.0
    # gait_freq가 없으면 기본값 사용
    gait_freq = getattr(command, "gait_freq", 1.5) 

    # 2. 발 접촉 여부 (Contact Sensor)
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    
    # sensor_cfg.body_ids는 RewardManager가 SceneEntityCfg를 처리할 때 자동 할당됨
    # net_forces shape: (num_envs, num_selected_bodies, 3)
    forces = contact_sensor.data.net_forces_w[:, sensor_cfg.body_ids, :]
    
    # 힘의 크기가 1.0 이상이면 접촉으로 간주
    is_contact = torch.norm(forces, dim=-1) > 1.0

    # 3. Swing Target 계산 (Phase 기반)
    # 0.25 근처: 왼발(0번) Swing / 0.75 근처: 오른발(1번) Swing
    # (주의: env_cfg에서 body_names 순서가 [왼발, 오른발]이어야 함)
    
    left_swing_target = (torch.abs(gait_phase - 0.25) < 0.5 * swing_period) & (gait_freq > 0.01)
    right_swing_target = (torch.abs(gait_phase - 0.75) < 0.5 * swing_period) & (gait_freq > 0.01)
    
    # 4. 보상 계산: (목표가 Swing) AND (실제로 접촉이 없음)
    # is_contact[:, 0] : 첫 번째 발, is_contact[:, 1] : 두 번째 발
    reward = (left_swing_target & ~is_contact[:, 0]).float() + \
             (right_swing_target & ~is_contact[:, 1]).float()
             
    return reward


def feet_distance_reward(
    env: ManagerBasedRLEnv, 
    asset_name: str, 
    feet_names: list[str], 
    target_dist: float = 0.2
) -> torch.Tensor:
    """
    [T1 Logic] 두 발 사이의 Y축 간격 유지 보상
    """
    robot = env.scene[asset_name]
    
    # 발의 Body Index 찾기 (매번 찾으면 느리지만, 초기화 단계가 아니라서 여기서 처리)
    # 최적화를 위해서는 모듈 레벨이나 클래스 변수로 캐싱하는 것이 좋음
    feet_indices, _ = robot.find_bodies(feet_names)
    
    # 로봇 기준(Base Frame) 발 위치 사용
    feet_pos_w = robot.data.body_pos_w[:, feet_indices, :]
    
    # 로봇 기준 Y축(좌우) 거리 차이
    # feet_pos_b shape: (num_envs, 2, 3) -> [:, 1, 1]은 두번째 발의 y, [:, 0, 1]은 첫번째 발의 y
    feet_dist_y = torch.abs(feet_pos_w[:, 1, 1] - feet_pos_w[:, 0, 1])
    
    # target_dist보다 가까우면(좁으면) 보상 (clip min=0, max=0.1)
    # 의미: 발이 너무 벌어지지 않도록(혹은 특정 간격 유지) 유도
    return torch.clip(target_dist - feet_dist_y, min=0.0, max=0.1)


def feet_slip_reward(
    env: ManagerBasedRLEnv, 
    asset_name: str, 
    feet_names: list[str],
    sensor_cfg: SceneEntityCfg,
    threshold: float = 1.0
) -> torch.Tensor:
    """
    [T1 Logic] 발 미끄러짐 벌점 (접촉 중인데 속도가 있을 때)
    """
    robot = env.scene[asset_name]
    contact_sensor = env.scene.sensors[sensor_cfg.name]
    
    feet_indices, _ = robot.find_bodies(feet_names)
    
    # 발 속도 (World Frame)
    feet_vel = robot.data.body_lin_vel_w[:, feet_indices, :]
    
    # 접촉 여부 (센서 데이터)
    forces = contact_sensor.data.net_forces_w[:, sensor_cfg.body_ids, :]
    is_contact = torch.norm(forces, dim=-1) > threshold
    
    # 미끄러짐 속도 제곱의 합 (접촉 중인 발만 계산)
    slip = torch.sum(torch.square(feet_vel).sum(dim=-1) * is_contact.float(), dim=-1)
    
    return slip  # Weight를 음수로 주어야 페널티가 됨


def feet_height_reward(
    env: ManagerBasedRLEnv,
    asset_name: str,
    target_height: float,
    std: float = 1.0 # unused in logic but kept for signature compatibility if needed
) -> torch.Tensor:
    """
    [T1 Logic] 로봇 베이스 높이 유지 (Error Square)
    """
    robot = env.scene[asset_name]
    
    # 현재 Base 높이 (World Z)
    base_height = robot.data.root_pos_w[:, 2]
    
    # 에러 제곱 (작을수록 좋음 -> Weight 음수 필요)
    error = torch.square(base_height - target_height)
    return error

def zmp_reward(
    env: ManagerBasedRLEnv, 
    sensor_cfg: SceneEntityCfg, 
    asset_name: str,
    std: float = 0.05
) -> torch.Tensor:
    """
    [T1 Logic] ZMP(Zero Moment Point)가 지지면 중심에 위치하도록 유도하는 보상
    """
    # 1. 데이터 가져오기
    contact_sensor = env.scene.sensors[sensor_cfg.name]
    robot = env.scene[asset_name]
    
    # net_forces_w: (num_envs, 2, 3) -> [:, :, 2]는 수직 항력(Fz)
    forces_z = contact_sensor.data.net_forces_w[:, sensor_cfg.body_ids, 2]
    # body_pos_w: (num_envs, 2, 3) -> 발의 현재 위치
    feet_pos = robot.data.body_pos_w[:, sensor_cfg.body_ids, :2] # XY 평면만 사용
    
    total_force_z = torch.sum(forces_z, dim=-1)
    
    # 2. 접촉 여부 확인 (최소 1.0N 이상의 힘이 가해질 때만 계산)
    contact_mask = total_force_z > 1.0
    
    # 3. ZMP 계산 (수직 항력 가중 평균)
    # ZMP_x = sum(Fz_i * x_i) / sum(Fz_i)
    # forces_z.unsqueeze(-1) shape: (num_envs, 2, 1)
    safe_total_force = torch.where(contact_mask, total_force_z, torch.ones_like(total_force_z))
    zmp_pos = torch.sum(forces_z.unsqueeze(-1) * feet_pos, dim=1) / safe_total_force.unsqueeze(-1)
    
    # 4. 목표 지점 (두 발의 중심점)
    support_center = torch.mean(feet_pos, dim=1)
    
    # 5. 에러 계산 및 지수 커널 보상
    zmp_error = torch.sum(torch.square(zmp_pos - support_center), dim=-1)
    reward = torch.exp(-zmp_error / (std**2))
    
    # 접촉이 전혀 없는 상태(공중)라면 보상 0
    return torch.where(contact_mask, reward, torch.zeros_like(reward))
# -------------------------------------------------------------------------
# Rewards Config Definition
# -------------------------------------------------------------------------

@configclass
class RewardsCfg:
    """
    Reward terms for the T1 environment.
    env_cfg.py에서 이 클래스를 인스턴스화하여 사용합니다.
    """
    
    # 1. Base Velocity Tracking (Exp Kernel)
    track_lin_vel_x = RewardTermCfg(
        func=track_lin_vel_x_exp,
        weight=1.0,
        params={
            "command_name": "base_velocity",  # env_cfg.py의 commands 이름과 일치해야 함
            "std": 0.25,
        },
    )

    track_lin_vel_y = RewardTermCfg(
        func=track_lin_vel_y_exp,
        weight=1.0,
        params={
            "command_name": "base_velocity",
            "std": 0.25,
        },
    )

    track_ang_vel_z = RewardTermCfg(
        func=track_ang_vel_z_exp,
        weight=0.5,
        params={
            "command_name": "base_velocity",
            "std": 0.25,
        },
    )

    # 2. Feet Swing Reward (Gait Phase Matching)
    feet_swing = RewardTermCfg(
        func=feet_swing_reward,
        weight=5.0,  # 보통 Swing 보상은 큼
        params={
            "command_name": "base_velocity",
            "sensor_cfg": SceneEntityCfg("contact_forces", 
                                         body_names=["left_foot_link", "right_foot_link"]), # T1 URDF 발 이름 확인 필요 (보통 ankle or foot)
            "swing_period": 0.5,
        },
    )

    # 3. Feet Distance (Width)
    feet_distance = RewardTermCfg(
        func=feet_distance_reward,
        weight=0.2,
        params={
            "asset_name": "robot",
            "feet_names": ["left_foot_link", "right_foot_link"], # 정규식 리스트
            "target_dist": 0.2,
        },
    )

    # 4. Feet Slip (Penalty)
    feet_slip = RewardTermCfg(
        func=feet_slip_reward,
        weight=-0.5, # Penalty
        params={
            "asset_name": "robot",
            "feet_names": ["left_foot_link", "right_foot_link"],
            "sensor_cfg": SceneEntityCfg("contact_forces", 
                                         body_names=["left_foot_link", "right_foot_link"]),
            "threshold": 1.0,
        },
    )

    # 5. Base Height Maintenance (Penalty style)
    feet_height = RewardTermCfg(
        func=feet_height_reward,
        weight=-2.0, # Error 제곱을 반환하므로 음수 가중치
        params={
            "asset_name": "robot",
            "target_height": 0.65, # T1 로봇의 적정 높이 (URDF init_state 참고하여 조정)
            "std": 1.0, # 함수 시그니처 맞춤용
        },
    )
# -----------------------------------------------------------------
    # 필수 추가 항목: 생존 및 자세 유지 (T1.yaml 기준)
    # -----------------------------------------------------------------

    # 1. 생존 보상 (오래 살아남을수록 보상)
    survival = RewardTermCfg(
        func=mdp.is_alive,
        weight=0.25,
    )

    # 2. 자세 유지 페널티 (몸체가 기울어지는 것을 강력히 방지)
    orientation = RewardTermCfg(
        func=mdp.flat_orientation_l2,
        weight=-5.0,
        # [수정] asset_name(문자열) -> asset_cfg(SceneEntityCfg 객체)로 변경
        params={"asset_cfg": SceneEntityCfg("robot")}, 
    )

    # 3. Z축(위아래) 출렁임 페널티
    lin_vel_z = RewardTermCfg(
        func=mdp.lin_vel_z_l2,
        weight=-2.0,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )

    # 4. 불필요한 몸통 회전 페널티 (XY축 회전 방지)
    ang_vel_xy = RewardTermCfg(
        func=mdp.ang_vel_xy_l2,  # [수정] base_ang_vel_xy_l2 -> ang_vel_xy_l2
        weight=-0.2,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )

    # -----------------------------------------------------------------
    # 필수 추가 항목: 에너지 효율 및 부드러운 움직임 (T1.yaml 기준)
    # -----------------------------------------------------------------

    # 5. 과도한 힘(Torque) 사용 페널티
    torques = RewardTermCfg(
        func=mdp.joint_torques_l2,
        weight=-2.0e-4,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )

    # 6. 관절 속도 페널티 (너무 빨리 휙휙 움직이는 것 방지)
    dof_vel = RewardTermCfg(
        func=mdp.joint_vel_l2,
        weight=-1.0e-4,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )

    # 7. 관절 가속도 페널티 (덜덜 떨리는 현상 방지)
    dof_acc = RewardTermCfg(
        func=mdp.joint_acc_l2,
        weight=-1.0e-7,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )

    # 8. 액션 변화율 페널티 (급격한 명령 변경 방지)
    action_rate = RewardTermCfg(
        func=mdp.action_rate_l2,
        weight=-1.0,
        # 이 함수는 로봇 전체의 액션 버퍼를 확인하므로 asset_cfg가 필요 없습니다.
    )

    # 9. 관절 한계 도달 페널티 (관절이 꺾이는 한계점까지 가는 것 방지)
    dof_pos_limits = RewardTermCfg(
        func=mdp.joint_pos_limits,
        weight=-1.0,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )
    
    zmp_stability = RewardTermCfg(
        func=zmp_reward,
        weight=2.0,  # 안정성을 위해 적절히 높은 가중치 부여
        params={
            "asset_name": "robot",
            "sensor_cfg": SceneEntityCfg("contact_forces", 
                                         body_names=["left_foot_link", "right_foot_link"]),
            "std": 0.05, # 5cm 이내로 들어오도록 유도
        },
    )
    # 6. Action Smoothness (Penalty) - Isaac Lab 기본 함수 사용 예시
    # 필요하다면 mdp.action_rate_l2 등을 추가