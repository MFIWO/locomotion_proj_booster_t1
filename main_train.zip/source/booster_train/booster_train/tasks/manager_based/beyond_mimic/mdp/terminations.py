from __future__ import annotations

import torch
from typing import TYPE_CHECKING

from isaaclab.managers import SceneEntityCfg, TerminationTermCfg
from isaaclab.sensors import ContactSensor
from isaaclab.utils import configclass

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv

# --- Termination Functions (Logic) ---

def base_height_below(
    env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg, minimum_height: float
) -> torch.Tensor:
    """
    [T1 Logic] 로봇의 Base 높이가 일정 수준 이하로 떨어지면 종료 (넘어짐 감지).
    """
    # 로봇 객체 가져오기 (SceneEntityCfg를 통해 이름으로 접근)
    asset = env.scene[asset_cfg.name]
    
    # Root Position (World Frame)
    # data.root_pos_w[:, 2] -> Z축 높이
    root_pos_z = asset.data.root_pos_w[:, 2]
    
    return root_pos_z < minimum_height


def illegal_contact(
    env: ManagerBasedRLEnv, sensor_cfg: SceneEntityCfg, threshold: float = 1.0
) -> torch.Tensor:
    """
    [T1 Logic] 허용되지 않은 부위(발 제외)가 땅에 닿으면 종료.
    """
    # Contact Sensor 가져오기
    sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    
    # sensor_cfg.body_ids는 Reward/Termination Manager가 
    # body_names(정규식)를 해석하여 해당 인덱스 리스트를 자동으로 채워줍니다.
    # net_forces_w shape: (num_envs, num_monitored_bodies, 3)
    forces = sensor.data.net_forces_w[:, sensor_cfg.body_ids, :]
    
    # 힘의 크기(Norm)가 임계값보다 크면 접촉으로 간주
    # dim=-1 (x,y,z 벡터의 크기), dim=1 (모니터링하는 바디들 중 하나라도)
    return torch.any(torch.norm(forces, dim=-1) > threshold, dim=1)


def root_velocity_above(
    env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg, threshold: float
) -> torch.Tensor:
    """
    [T1 Logic] 로봇의 속도가 너무 빠르면(폭주) 종료.
    """
    asset = env.scene[asset_cfg.name]
    
    # Root Velocity (Linear + Angular)
    # root_vel_w shape: (num_envs, 6) -> [vx, vy, vz, wx, wy, wz]
    root_vel = asset.data.root_vel_w
    
    # 속도 제곱의 합이 threshold를 넘는지 확인
    # sum(dim=-1) -> 각 환경별 속도 에너지 총합
    return torch.sum(torch.square(root_vel), dim=-1) > threshold


# --- Configuration Class (Fix) ---

@configclass
class TerminationsCfg:
    """
    Termination terms for the T1 environment.
    env_cfg.py에서 이 클래스를 인스턴스화하여 사용합니다.
    """
    
    # 1. 넘어짐 감지 (Base 높이가 너무 낮을 때)
    base_height = TerminationTermCfg(
        func=base_height_below,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "minimum_height": 0.3, # T1 로봇 다리 길이에 맞춰 조절 (너무 낮으면 엎드려도 죽음)
        },
    )

    # 2. 허용되지 않은 접촉 (무릎, 허벅지, 몸통 등이 닿았을 때)
    illegal_contact = TerminationTermCfg(
        func=illegal_contact,
        params={
            "sensor_cfg": SceneEntityCfg(
                "contact_forces",  # env_cfg.py의 ContactSensor 이름
                # 발(ankle/foot)을 제외한 나머지 부위가 닿으면 종료
                # 아래 정규식은 로봇 URDF에 맞춰 수정 필요 (예: thigh, hip, base 등)
                body_names=[
                    "Trunk",
                    "Hip_.*",
                    "Shank_.*",
                    "Ankle_.*"
                ], 
            ),
            "threshold": 1.0,
        },
    )
    
    # 3. 속도 폭주 감지 (물리 시뮬레이션 폭발 방지)
    root_velocity = TerminationTermCfg(
        func=root_velocity_above,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "threshold": 200.0, # 속도 제곱의 합 (아주 빠른 상태)
        },
    )

    # 4. (선택사항) 타임아웃
    # RL 학습 시 보통 에피소드 최대 길이가 정해져 있으므로, 
    # ManagerBasedRLEnvCfg의 episode_length_s로 자동 처리되지만 명시적으로 추가하기도 함.
    # 여기서는 env_cfg의 is_finite_horizon 설정을 따르므로 생략 가능.