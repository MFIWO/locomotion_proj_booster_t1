# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import gymnasium as gym

##
# Register Gym environments.
##

gym.register(
    id="Booster-T1-Locomotion-v0",  # [수정] 우리가 실행할 때 쓰는 이름 (--task 옵션)
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        # [수정] env_cfg.py 파일 안에 우리가 만든 'T1RoughEnvCfg' 클래스를 연결
        "env_cfg_entry_point": f"{__name__}.env_cfg:T1RoughEnvCfg",
        "rsl_rl_cfg_entry_point": f"{__name__}.ppo_cfg:PPORunnerCfg",
    },
)

# 2. 플레이/테스트용 (Play) 환경 등록
gym.register(
    id="Booster-T1-Locomotion-v0-Play", # [수정] Play 모드 이름
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        # [수정] env_cfg.py 파일 안에 우리가 만든 'T1FlatEnvCfg' 클래스를 연결
        "env_cfg_entry_point": f"{__name__}.env_cfg:T1FlatEnvCfg",
        "rsl_rl_cfg_entry_point": f"{__name__}.ppo_cfg:PPORunnerCfg",
    },
)