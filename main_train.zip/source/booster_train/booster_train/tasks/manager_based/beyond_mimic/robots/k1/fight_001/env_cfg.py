from __future__ import annotations

import math
import torch   
from dataclasses import MISSING
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.terrains import TerrainGeneratorCfg

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import CommandTermCfg  # ★ 추가

from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import ContactSensorCfg
from isaaclab.terrains import TerrainImporterCfg, TerrainGeneratorCfg, MeshPlaneTerrainCfg, HfRandomUniformTerrainCfg
from isaaclab.utils import configclass

from isaaclab.managers import CurriculumTermCfg as CurrTerm
import isaaclab.envs.mdp as mdp
from isaaclab.utils.noise import gaussian_noise
from isaaclab.utils.noise.noise_cfg import GaussianNoiseCfg, NoiseModelCfg

# --- 커스텀 모듈 Import (앞서 작성한 파일들) ---
from booster_train.tasks.manager_based.beyond_mimic.mdp import rewards as custom_rewards
from booster_train.tasks.manager_based.beyond_mimic.mdp import terminations as custom_terminations
from booster_train.tasks.manager_based.beyond_mimic.mdp import commands as custom_commands

BOOSTER_ASSETS_DIR = r"C:\Users\user\Downloads\booster_assets"

# -------------------------------------------------------------------------
# 1. 로봇 설정 (T1.yaml 참고)
# -------------------------------------------------------------------------
# T1 로봇의 Actuator 설정 (PD Gain)
# stiffness: {'Hip_Roll': 200, 'Hip_Yaw': 200, 'Hip_Pitch': 200, 'Knee_.*': 200, 'Ankle_.*': 20}
# damping: {'Hip_Roll': 5, 'Hip_Yaw': 5, 'Hip_Pitch': 5, 'Knee_.*': 5, 'Ankle_.*': 4}

T1_ACTUATOR_CFG = ImplicitActuatorCfg(
    joint_names_expr=[".*"],
    stiffness={
        ".*_Hip_Roll": 200.0, ".*_Hip_Yaw": 200.0, ".*_Hip_Pitch": 200.0,
        ".*_Knee_.*": 200.0, ".*_Ankle_.*": 20.0,
    },
    damping={
        ".*_Hip_Roll": 5.0, ".*_Hip_Yaw": 5.0, ".*_Hip_Pitch": 5.0,
        ".*_Knee_.*": 5.0, ".*_Ankle_.*": 4.0,
    },
    armature=0.01, # T1.yaml armature
)

T1_ROBOT_CFG = ArticulationCfg(
    spawn=sim_utils.UrdfFileCfg(  # [수정] UsdFileCfg -> UrdfFileCfg로 변경
        # [수정] usd_path -> asset_path로 변경하고 .urdf 파일 지정
        asset_path=f"{BOOSTER_ASSETS_DIR}/robots/T1/T1_23dof.urdf",
        
        # URDF 로드 옵션 추가 (변환 스크립트에서 주려던 옵션들)
        merge_fixed_joints=True,      # --merge-joints 옵션 대응
        make_instanceable=True,       # --make-instanceable 옵션 대응
        fix_base=False,               # 고정되지 않음 (보행 로봇이므로)

        #default_drive_type="position",# 기본 구동 방식 (필요시)
        joint_drive=sim_utils.UrdfConverterCfg.JointDriveCfg(
        drive_type="force",
        target_type="position",
        gains=sim_utils.UrdfConverterCfg.JointDriveCfg.PDGainsCfg(
            stiffness=200.0,   # ★ 반드시 값 필요
            damping=5.0,
            ),
        ),
        
        activate_contact_sensors=True,
        rigid_props=sim_utils.RigidBodyPropertiesCfg(
            disable_gravity=False,
            retain_accelerations=False,
            linear_damping=0.0,
            angular_damping=0.0,
            max_linear_velocity=1000.0,
            max_angular_velocity=1000.0,
            max_depenetration_velocity=1.0,
        ),
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(
            enabled_self_collisions=True,
            solver_position_iteration_count=4,
            solver_velocity_iteration_count=0,
            sleep_threshold=0.005,
            stabilization_threshold=0.001,
        ),
    ),
    init_state=ArticulationCfg.InitialStateCfg(
        pos=(0.0, 0.0, 1.05),
        joint_pos={
            # T1.yaml 파일의 관절 이름과 대소문자가 정확히 일치해야 합니다!
            ".*_Hip_Roll": 0.0, 
            ".*_Hip_Yaw": 0.0, 
            ".*_Hip_Pitch": -0.3,
            ".*_Knee_.*": 0.6, 
            ".*_Ankle_.*": -0.3,
        },
        joint_vel={".*": 0.0},
    ),
    actuators={"legs": T1_ACTUATOR_CFG},
)

# -------------------------------------------------------------------------
# 2. Scene Definition
# -------------------------------------------------------------------------
@configclass
class T1SceneCfg(InteractiveSceneCfg):
    """Configuration for the terrain scene with the T1 robot."""

    # 지형 설정 (Rough Terrain)
    terrain = TerrainImporterCfg(
        prim_path="/World/ground",
        
        # [수정] sim_utils.TerrainGeneratorCfg -> TerrainGeneratorCfg
        terrain_generator=TerrainGeneratorCfg(
            size=(8.0, 8.0),
            seed=42,
            sub_terrains={
                "flat": MeshPlaneTerrainCfg(
                    proportion=0.2
                ),
                "rough_lo": HfRandomUniformTerrainCfg(
                    proportion=0.4,
                    noise_range=(0.0, 0.03),
                    noise_step=0.01,
                ),
                "rough_hi": HfRandomUniformTerrainCfg(
                    proportion=0.4,
                    noise_range=(0.0, 0.06),
                    noise_step=0.01,
                ),
            },
        ),
        max_init_terrain_level=5,
        collision_group=-1,
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.0,
            dynamic_friction=1.0,
        ),
        debug_vis=False,
    )

    # 로봇 추가
    robot = T1_ROBOT_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")

    # 센서 추가 (발바닥 접촉 감지 - Reward용)
    contact_forces = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/.*", 
        history_length=3, 
        track_air_time=True
    )
    
    # 조명
    light = AssetBaseCfg(
        prim_path="/World/light",
        spawn=sim_utils.DistantLightCfg(color=(0.75, 0.75, 0.75), intensity=3000.0),
    )


# -------------------------------------------------------------------------
# 3. Actions & Observations
# -------------------------------------------------------------------------
@configclass
class ActionsCfg:
    """Action specifications for the MDP."""
    joint_pos = mdp.JointPositionActionCfg(
        asset_name="robot", 
        joint_names=[".*"], 
        scale=0.25,   # T1.yaml: action_scale
        use_default_offset=True
    )

def make_gaussian_noise(std: float, mean: float = 0.0):
    return NoiseModelCfg(
        noise_cfg=GaussianNoiseCfg(
            mean=mean,
            std=std,
            operation="add",
            func=gaussian_noise,
        )
    )

def gait_clock_sin_fn(env):
    phase = env.command_manager.get_term("base_velocity").gait_phase
    return torch.sin(2 * torch.pi * phase).unsqueeze(1)


def gait_clock_cos_fn(env):
    phase = env.command_manager.get_term("base_velocity").gait_phase
    return torch.cos(2 * torch.pi * phase).unsqueeze(1)

@configclass
class ObservationsCfg:
    """Observation specifications for the MDP."""
    @configclass
    class PolicyCfg(ObsGroup):
        # 1. Base Lin Vel (Scale 2.0)

        base_lin_vel = ObsTerm(
            func=mdp.base_lin_vel,
            noise=make_gaussian_noise(std=0.1),   # ✅ 수정
            scale=2.0
        )

        base_ang_vel = ObsTerm(
            func=mdp.base_ang_vel,
            noise=make_gaussian_noise(std=0.2),   # ✅ 수정
            scale=0.25
        )

        projected_gravity = ObsTerm(
            func=mdp.projected_gravity,
            noise=make_gaussian_noise(std=0.05),  # ✅ 수정
        )

        velocity_commands = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "base_velocity"},
            scale=(2.0, 2.0, 0.25)
        )

        gait_clock_sin = ObsTerm(
            func=gait_clock_sin_fn   # ✅ lambda 제거
        )

        gait_clock_cos = ObsTerm(
            func=gait_clock_cos_fn   # ✅ lambda 제거
        )

        joint_pos = ObsTerm(
            func=mdp.joint_pos_rel,
            noise=make_gaussian_noise(std=0.01),   # ✅ 수정
            scale=1.0
        )

        joint_vel = ObsTerm(
            func=mdp.joint_vel,
            noise=make_gaussian_noise(std=1.5),    # ✅ 수정
            scale=0.05
        )

        actions = ObsTerm(func=mdp.last_action)

    policy: PolicyCfg = PolicyCfg()


# -------------------------------------------------------------------------
# 4. Events (Randomization)
# -------------------------------------------------------------------------
@configclass
class EventCfg:
    """Configuration for events."""
    # 시작 시 물리 상태 리셋
    reset_base = EventTerm(
        func=mdp.reset_root_state_uniform,
        mode="reset",
        params={
            "pose_range": {"x": (-0.5, 0.5), "y": (-0.5, 0.5), "Yaw": (-3.14, 3.14)},
            "velocity_range": {
                "x": (-0.1, 0.1), "y": (-0.1, 0.1), "z": (-0.1, 0.1),
                "Roll": (-0.1, 0.1), "Pitch": (-0.1, 0.1), "Yaw": (-0.1, 0.1),
            },
        },
    )
    
    reset_robot_joints = EventTerm(
        func=mdp.reset_joints_by_scale,
        mode="reset",
        params={
            "position_range": (0.5, 1.5),
            "velocity_range": (0.0, 0.0),
        },
    )

    # 주기적으로 로봇 밀기 (External Push)
    push_robot = EventTerm(
        func=mdp.push_by_setting_velocity,
        mode="interval",
        interval_range_s=(10.0, 15.0), # push_interval_s
        params={"velocity_range": {"x": (-1.0, 1.0), "y": (-1.0, 1.0)}},
    )

    physics_material = EventTerm(
            func=mdp.randomize_rigid_body_material,
            mode="startup",
            params={
                "asset_cfg": SceneEntityCfg("robot"),
                "static_friction_range": (0.6, 1.2),  # 기본 1.0에서 +-변화
                "dynamic_friction_range": (0.6, 1.0),
                "restitution_range": (0.0, 0.0),      # 탄성(통통 튀는 정도)은 0으로 고정
                "num_buckets": 64,                    # 64가지 종류의 마찰력을 랜덤 생성
            },
        )

        # 5. 로봇 링크 질량(Mass) 랜덤화 (배터리 무게 변화 등)
    randomize_mass = EventTerm(
        func=mdp.randomize_rigid_body_mass,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "mass_distribution_params": (-2.0, 3.0), # 원래 질량에서 -2kg ~ +3kg 변화
            "operation": "add",
        },
    )

# -------------------------------------------------------------------------
# 5. Main Env Config
# -------------------------------------------------------------------------
@configclass
class T1RoughEnvCfg(ManagerBasedRLEnvCfg):
    """
    Main Training Configuration for T1 Locomotion
    """

    # 기본 설정
    is_finite_horizon = False
    episode_length_s = 20.0

    # 1. Scene
    scene: T1SceneCfg = T1SceneCfg(num_envs=4096, env_spacing=2.5)

    # 2. Observations
    observations: ObservationsCfg = ObservationsCfg()

    # 3. Actions
    actions: ActionsCfg = ActionsCfg()

    # 4. Commands (우리가 만든 커스텀 MotionCommandCfg 사용)

    @configclass
    class CommandsCfg:
        base_velocity: custom_commands.MotionCommandCfg = custom_commands.MotionCommandCfg(
        class_type=custom_commands.MotionCommand,
        resampling_time_range=(4.0, 4.0),
        asset_name="robot",
        ranges=custom_commands.MotionCommandCfg.Ranges(
            lin_vel_x=(-1.0, 1.0),
            lin_vel_y=(-1.0, 1.0),
            ang_vel_z=(-1.0, 1.0),
            gait_freq=(1.5, 3.0),
            ),
        )

    commands: CommandsCfg = CommandsCfg()  # ★ 수정

    # 5. Rewards (우리가 만든 커스텀 RewardsCfg 사용)
    # RewardsCfg 내부에서 `env_cfg.py`에 정의된 custom_rewards 함수들을 연결했는지 확인 필요
    # 혹은 여기서 직접 RewardsCfg를 재정의해도 됨.
    rewards: custom_rewards.RewardsCfg = custom_rewards.RewardsCfg()

    # 6. Terminations (우리가 만든 커스텀 TerminationsCfg 사용)
    terminations: custom_terminations.TerminationsCfg = custom_terminations.TerminationsCfg()

    # 7. Events
    events: EventCfg = EventCfg()

    def __post_init__(self):
        """Post initialization."""
        super().__post_init__()
        # 시뮬레이션 설정 (Decimation 4, dt=0.005 -> control dt=0.02)
        self.decimation = 4
        self.sim.dt = 0.005
        self.sim.render_interval = self.decimation * self.sim.dt
        
        # viewer settings
        self.viewer.eye = (3.0, 3.0, 3.0)
        self.viewer.lookat = (0.0, 0.0, 1.0)


@configclass
class T1FlatEnvCfg(T1RoughEnvCfg):
    """
    Play/Test Configuration (Flat Terrain)
    """
    def __post_init__(self):
        super().__post_init__()
        
        # 평지로 설정
        self.scene.terrain.terrain_type = "plane"
        self.scene.terrain.terrain_generator = None
        
        # 환경 개수 줄이기 (테스트용)
        self.scene.num_envs = 50
        
        # 랜덤 외력 끄기
        self.events.push_robot = None
        
        # 명령 고정 (테스트 편의를 위해)
        self.commands.base_velocity.ranges.lin_vel_x = (0.5, 0.5) # 앞으로 0.5m/s
        self.commands.base_velocity.ranges.lin_vel_y = (0.0, 0.0)
        self.commands.base_velocity.ranges.ang_vel_z = (0.0, 0.0)