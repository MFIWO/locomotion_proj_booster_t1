from __future__ import annotations

import math
from dataclasses import MISSING

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import ContactSensorCfg
from isaaclab.terrains import TerrainImporterCfg
from isaaclab.utils import configclass
from isaaclab.utils.noise import AdditiveUniformNoiseCfg as Unoise
from isaaclab.utils.noise import GaussianNoiseCfg as Gnoise

import isaaclab.envs.mdp as mdp

# --- 커스텀 모듈 (앞서 작성한 파일들) ---
from .mdp import rewards as custom_rewards
from .mdp import terminations as custom_terminations
from .mdp import commands as custom_commands  # MotionCommandCfg가 정의된 곳


# -------------------------------------------------------------------------
# 1. Scene & Robot Definition
# -------------------------------------------------------------------------

# T1 Actuator Gains (T1.yaml 참고)
T1_ACTUATOR_CFG = sim_utils.ActuatorNetMLPCfg(
    joint_names_expr=[".*"],
    stiffness={
        ".*_hip_roll": 200.0, ".*_hip_yaw": 200.0, ".*_hip_pitch": 200.0,
        ".*_knee": 200.0, ".*_ankle": 20.0,
        ".*": 200.0
    },
    damping={
        ".*_hip_roll": 5.0, ".*_hip_yaw": 5.0, ".*_hip_pitch": 5.0,
        ".*_knee": 5.0, ".*_ankle": 4.0,
        ".*": 5.0
    },
    armature=0.01,
)

@configclass
class MySceneCfg(InteractiveSceneCfg):
    """Configuration for the terrain scene with T1 robot."""

    # Ground Terrain (Rough Terrain 지원)
    terrain = TerrainImporterCfg(
        prim_path="/World/ground",
        terrain_type="generator",
        terrain_generator=sim_utils.TerrainGeneratorCfg(
            seed=42,
            sub_terrains={
                "flat": sim_utils.TerrainGeneratorCfg.SubTerrainCfg(
                    proportion=0.2, grid_height_range=(0, 0)),
                "rough_lo": sim_utils.TerrainGeneratorCfg.SubTerrainCfg(
                    proportion=0.4, grid_height_range=(0.0, 0.03)),
                "rough_hi": sim_utils.TerrainGeneratorCfg.SubTerrainCfg(
                    proportion=0.4, grid_height_range=(0.0, 0.06)),
            },
        ),
        max_init_terrain_level=5,
        collision_group=-1,
        physics_material=sim_utils.RigidBodyMaterialCfg(
            friction_combine_mode="multiply",
            restitution_combine_mode="multiply",
            static_friction=1.0,
            dynamic_friction=1.0,
        ),
        debug_vis=False,
    )

    # Robot (T1 USD)
    robot = ArticulationCfg(
        prim_path="{ENV_REGEX_NS}/Robot",
        spawn=sim_utils.UsdFileCfg(
            usd_path="resources/T1/T1_locomotion.usd", # 경로 확인 필수!
            activate_contact_sensors=True,
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                disable_gravity=False,
                retain_accelerations=False,
                linear_damping=0.0,
                angular_damping=0.0,
                max_linear_velocity=1000.0,
                max_angular_velocity=1000.0,
                max_depenetration_velocity=1.0,
            ),
            articulation_props=sim_utils.ArticulationRootPropertiesCfg(
                enabled_self_collisions=True,
                solver_position_iteration_count=4,
                solver_velocity_iteration_count=0,
                sleep_threshold=0.005,
                stabilization_threshold=0.001,
            ),
        ),
        init_state=ArticulationCfg.InitialStateCfg(
            pos=(0.0, 0.0, 1.05), # T1 초기 높이
            joint_pos={
                ".*_hip_roll": 0.0, ".*_hip_yaw": 0.0, ".*_hip_pitch": -0.3,
                ".*_knee": 0.6, ".*_ankle": -0.3,
            },
            joint_vel={".*": 0.0},
        ),
        actuators={"legs": T1_ACTUATOR_CFG},
    )

    # Lights
    light = AssetBaseCfg(
        prim_path="/World/light",
        spawn=sim_utils.DistantLightCfg(color=(0.75, 0.75, 0.75), intensity=3000.0),
    )
    sky_light = AssetBaseCfg(
        prim_path="/World/skyLight",
        spawn=sim_utils.DomeLightCfg(color=(0.13, 0.13, 0.13), intensity=1000.0),
    )

    # Sensors (발바닥 접촉 감지)
    contact_forces = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/.*", 
        history_length=3, 
        track_air_time=True, 
        force_threshold=1.0, 
        debug_vis=False # 디버그 끔
    )


# -------------------------------------------------------------------------
# 2. MDP Settings (Commands, Actions, Observations)
# -------------------------------------------------------------------------

@configclass
class CommandsCfg:
    """Command specifications for the MDP."""
    # [수정] 우리가 만든 Velocity+Gait 커맨드 사용
    base_velocity = custom_commands.MotionCommandCfg(
        asset_name="robot",
        resampling_time=4.0,
        ranges=custom_commands.MotionCommandCfg.Ranges(
            lin_vel_x=(-1.0, 1.0),
            lin_vel_y=(-1.0, 1.0),
            ang_vel_z=(-1.0, 1.0),
            gait_freq=(1.5, 3.0),
        ),
    )


@configclass
class ActionsCfg:
    """Action specifications for the MDP."""
    # [수정] 스케일 0.25 (T1.yaml action_scale)
    joint_pos = mdp.JointPositionActionCfg(
        asset_name="robot", 
        joint_names=[".*"], 
        scale=0.25, 
        use_default_offset=True
    )


@configclass
class ObservationsCfg:
    """Observation specifications for the MDP."""

    @configclass
    class PolicyCfg(ObsGroup):
        """Observations for policy group."""
        
        # 1. Base Velocity (Scale: 2.0, 0.25)
        base_lin_vel = ObsTerm(
            func=mdp.base_lin_vel, 
            noise=Gnoise(std=0.1), 
            scale=2.0
        )
        base_ang_vel = ObsTerm(
            func=mdp.base_ang_vel, 
            noise=Gnoise(std=0.2), 
            scale=0.25
        )
        
        # 2. Projected Gravity
        projected_gravity = ObsTerm(
            func=mdp.projected_gravity,
            noise=Gnoise(std=0.05),
        )
        
        # 3. Commands (Velocity 3 dim)
        velocity_commands = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "base_velocity"},
            scale={"lin_vel_x": 2.0, "lin_vel_y": 2.0, "ang_vel_z": 0.25}
        )
        
        # 4. Gait Clock (Sin/Cos 2 dim) - 커스텀 관측값
        gait_clock_sin = ObsTerm(
            func=lambda env: torch.sin(2 * torch.pi * env.command_manager.get_term("base_velocity").gait_phase).unsqueeze(1)
        )
        gait_clock_cos = ObsTerm(
            func=lambda env: torch.cos(2 * torch.pi * env.command_manager.get_term("base_velocity").gait_phase).unsqueeze(1)
        )
        
        # 5. Joint Pos/Vel
        joint_pos = ObsTerm(
            func=mdp.joint_pos_rel, 
            noise=Gnoise(std=0.01), 
            scale=1.0
        )
        joint_vel = ObsTerm(
            func=mdp.joint_vel, 
            noise=Gnoise(std=1.5), 
            scale=0.05
        )
        
        # 6. Last Actions
        actions = ObsTerm(func=mdp.last_action)

        def __post_init__(self):
            self.enable_corruption = True
            self.concatenate_terms = True

    # Critic Observation (선택 사항: Policy와 동일하거나 Privileged 정보 추가)
    # 여기서는 Policy와 동일하게 설정하거나 필요시 추가
    critic: PolicyCfg = PolicyCfg()


# -------------------------------------------------------------------------
# 3. MDP Settings (Rewards, Terminations, Events)
# -------------------------------------------------------------------------

@configclass
class RewardsCfg:
    """Reward terms for the MDP (T1 Locomotion)."""
    
    # [수정] Mimic 관련 보상 모두 제거하고, T1 Gym 보상으로 교체
    
    # 1. 속도 추적 (Gym Logic)
    track_lin_vel_x = RewTerm(
        func=custom_rewards.track_lin_vel_x_exp,
        weight=1.0,
        params={"command_name": "base_velocity", "std": 0.25},
    )
    track_lin_vel_y = RewTerm(
        func=custom_rewards.track_lin_vel_y_exp,
        weight=1.0,
        params={"command_name": "base_velocity", "std": 0.25},
    )
    track_ang_vel_z = RewTerm(
        func=custom_rewards.track_ang_vel_z_exp,
        weight=0.5,
        params={"command_name": "base_velocity", "std": 0.25},
    )
    
    # 2. 보행 박자 (Gait)
    feet_swing = RewTerm(
        func=custom_rewards.feet_swing_reward,
        weight=1.0,
        params={
            "command_name": "base_velocity",
            "sensor_cfg": SceneEntityCfg("contact_forces", body_names=[".*_left_foot.*", ".*_right_foot.*"]), # 정규표현식 확인
            "swing_period": 0.5
        }
    )
    
    # 3. 페널티 (Regularization)
    lin_vel_z = RewTerm(func=mdp.lin_vel_z_l2, weight=-2.0)
    ang_vel_xy = RewTerm(func=mdp.ang_vel_xy_l2, weight=-0.05)
    torques = RewTerm(func=mdp.joint_torques_l2, weight=-0.0002)
    dof_acc = RewTerm(func=mdp.joint_acc_l2, weight=-2.5e-7)
    action_rate = RewTerm(func=mdp.action_rate_l2, weight=-0.01)
    
    # 4. 종료 페널티
    # termination = RewTerm(func=mdp.is_terminated, weight=-200.0)


@configclass
class TerminationsCfg:
    """Termination terms for the MDP."""
    
    # [수정] Mimic 관련(anchor_pos 등) 제거, Locomotion 용으로 교체
    time_out = DoneTerm(func=mdp.time_out, time_out=True)
    
    base_height = DoneTerm(
        func=custom_terminations.base_height_below,
        params={"asset_cfg": SceneEntityCfg("robot"), "minimum_height": 0.3},
    )
    
    illegal_contact = DoneTerm(
        func=custom_terminations.illegal_contact,
        params={
            "sensor_cfg": SceneEntityCfg("contact_forces", body_names=[".*_thigh", ".*_shoulder", ".*_arm"]),
            "threshold": 1.0,
        },
    )


@configclass
class EventCfg:
    """Configuration for events (Domain Randomization)."""

    # 1. 물리 재질 랜덤화
    physics_material = EventTerm(
        func=mdp.randomize_rigid_body_material,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names=".*"),
            "static_friction_range": (0.3, 0.6),
            "dynamic_friction_range": (0.3, 0.6),
            "restitution_range": (0.0, 0.5),
            "num_buckets": 64,
        },
    )

    # 2. 질량 중심(COM) 랜덤화
    base_com = EventTerm(
        func=mdp.randomize_rigid_body_com,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names="Trunk"), # Body Name 확인!
            "com_range": {"x": (-0.02, 0.02), "y": (-0.02, 0.02), "z": (-0.02, 0.02)},
        },
    )
    
    # 3. 외부 충격 (Push)
    push_robot = EventTerm(
        func=mdp.push_by_setting_velocity,
        mode="interval",
        interval_range_s=(10.0, 15.0),
        params={"velocity_range": {"x": (-1.0, 1.0), "y": (-1.0, 1.0)}},
    )


# -------------------------------------------------------------------------
# 4. Main Environment Config
# -------------------------------------------------------------------------

@configclass
class TrackingEnvCfg(ManagerBasedRLEnvCfg):
    """Configuration for the T1 Locomotion velocity-tracking environment."""

    # Scene settings
    scene: MySceneCfg = MySceneCfg(num_envs=4096, env_spacing=2.5)
    
    # Basic settings
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    commands: CommandsCfg = CommandsCfg()
    
    # MDP settings
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()
    
    # Curriculum settings (Terrain Levels)
    curriculum = mdp.CurriculumCfg(
        terrain_levels=mdp.TerrainLevelsCfg(
            func=mdp.terrain_levels_vel,
            params={"command_name": "base_velocity"},
        )
    )

    def __post_init__(self):
        """Post initialization."""
        # general settings
        self.decimation = 4
        self.episode_length_s = 20.0 # T1.yaml episode_length_s
        
        # simulation settings
        self.sim.dt = 0.005
        self.sim.render_interval = self.decimation * self.sim.dt
        self.sim.physics_material = self.scene.terrain.physics_material
        
        # viewer settings
        self.viewer.eye = (3.0, 3.0, 3.0)
        self.viewer.lookat = (0.0, 0.0, 1.0)